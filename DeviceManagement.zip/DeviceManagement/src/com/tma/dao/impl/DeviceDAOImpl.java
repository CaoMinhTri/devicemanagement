package com.tma.dao.impl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tma.dao.DeviceDAO;
import com.tma.entities.Device;
@Repository("deviceDAO")
public class DeviceDAOImpl implements DeviceDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void create(Device device) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().persist(device);
	}

	@Override
	public void remove(Device device) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().delete(device);
	}

	@Override
	public void edit(Device device) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(device);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Device> findAll() {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createCriteria(Device.class).list();
	}

	@Override
	public Device find(int id) {
		// TODO Auto-generated method stub
		return (Device) sessionFactory.getCurrentSession().get(Device.class, id);
	}

}
