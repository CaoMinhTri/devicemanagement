package com.tma.dao;

import java.util.List;

import com.tma.entities.User;

public interface UserDAO {
	public void create(User user);
	public void remove(User user);
	public void edit(User user);
    public List<User> findAll();
    public User find(int id);
}
