package com.tma.dao;

import java.util.List;

import com.tma.entities.Device;

public interface DeviceDAO {
	public void create(Device device);
	public void remove(Device device);
	public void edit(Device device);
    public List<Device> findAll();
    public Device find(int id);
}
